# API de Cobertura - Tomodat + Wasapi

Función serverless para verificar cobertura de red usando Tomodat, deployada en Vercel.

## Deploy en Vercel (paso a paso)

### 1. Crear cuenta en Vercel
- Entrá a https://vercel.com y creá una cuenta gratuita (podés usar GitHub, Google o email)

### 2. Instalar Vercel CLI
```bash
npm install -g vercel
```

### 3. Deployar
```bash
cd cobertura-api
vercel
```
Seguí los pasos que te pide (nombre del proyecto, etc.). Todo dejar en default.

### 4. Configurar variable de entorno
En el dashboard de Vercel:
- Entrá a tu proyecto → Settings → Environment Variables
- Agregá:
  - **Name:** `TOMODAT_TOKEN`
  - **Value:** `b3b3a48a2156c9ff0f7ced7340e29186b4c63116`

Luego redeploy:
```bash
vercel --prod
```

## Uso de la API

### GET
```
GET https://tu-proyecto.vercel.app/api/cobertura?direccion=Av San Martin 1234 Moron
```

### POST
```
POST https://tu-proyecto.vercel.app/api/cobertura
Content-Type: application/json

{
  "direccion": "Av San Martin 1234, Morón"
}
```

### Respuesta con cobertura
```json
{
  "ok": true,
  "hayCobertura": true,
  "direccionEncontrada": "Av. San Martín 1234, Morón, Buenos Aires",
  "coordenadas": { "lat": "-34.757", "lon": "-58.645" },
  "cajasDisponibles": 3,
  "mensaje": "✅ ¡Buenas noticias! Tenemos cobertura en Av. San Martín 1234..."
}
```

### Respuesta sin cobertura
```json
{
  "ok": true,
  "hayCobertura": false,
  "mensaje": "❌ Por el momento no tenemos cobertura en esa dirección..."
}
```

## Configurar en Wasapi

En el flujo de Wasapi:
1. Preguntarle al cliente su dirección
2. Hacer un webhook POST a `https://tu-proyecto.vercel.app/api/cobertura`
3. Body: `{ "direccion": "{{variable_direccion}}" }`
4. Leer el campo `mensaje` de la respuesta y enviárselo al cliente
5. Leer el campo `hayCobertura` (true/false) para bifurcar el flujo

## Estructura de archivos
```
cobertura-api/
├── api/
│   └── cobertura.js   ← función principal
├── vercel.json        ← configuración de Vercel
└── README.md
```
