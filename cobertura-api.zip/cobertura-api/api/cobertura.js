const TOMODAT_TOKEN = process.env.TOMODAT_TOKEN;
const RADIO_METROS = 300;

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Aceptar GET y POST
  const direccion = req.method === 'POST'
    ? req.body?.direccion
    : req.query?.direccion;

  if (!direccion) {
    return res.status(400).json({
      ok: false,
      mensaje: 'Falta el parámetro "direccion"'
    });
  }

  try {
    // 1. Geocodificar con Nominatim
    const geoUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(direccion)}&format=json&limit=1`;
    const geoRes = await fetch(geoUrl, {
      headers: { 'User-Agent': 'CoberturaBot/1.0' }
    });
    const geoData = await geoRes.json();

    if (!geoData || geoData.length === 0) {
      return res.status(200).json({
        ok: false,
        mensaje: '❌ No pudimos encontrar esa dirección. ¿Podés escribirla más completa? Por ejemplo: *Av. San Martín 1234, Morón*'
      });
    }

    const { lat, lon, display_name } = geoData[0];

    // 2. Consultar Tomodat
    const tomodatUrl = `https://sys.tomodat.com.br/tomodat/api/clients/viability/${lat}/${lon}/${RADIO_METROS}`;
    const tomodatRes = await fetch(tomodatUrl, {
      headers: {
        'Authorization': `Bearer ${TOMODAT_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    const cajas = await tomodatRes.json();

    // 3. Verificar si hay puertos libres
    const cajasConPuertos = Array.isArray(cajas)
      ? cajas.filter(c =>
          c.splitters?.some(s => s.free_ports_number > 0)
        )
      : [];

    const hayCobertura = cajasConPuertos.length > 0;

    return res.status(200).json({
      ok: true,
      hayCobertura,
      direccionEncontrada: display_name,
      coordenadas: { lat, lon },
      cajasDisponibles: cajasConPuertos.length,
      mensaje: hayCobertura
        ? `✅ ¡Buenas noticias! Tenemos cobertura en *${display_name}*. Un asesor se va a contactar con vos a la brevedad para coordinar la instalación.`
        : `❌ Por el momento no tenemos cobertura en *${display_name}*. Te anotamos en lista de espera y te avisamos cuando lleguemos a tu zona.`
    });

  } catch (error) {
    console.error('Error:', error);
    return res.status(500).json({
      ok: false,
      mensaje: '⚠️ Hubo un error al verificar la cobertura. Por favor intentá de nuevo.'
    });
  }
}
